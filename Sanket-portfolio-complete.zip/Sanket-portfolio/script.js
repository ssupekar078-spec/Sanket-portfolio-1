const menuToggle=document.getElementById("menuToggle");
const navLinks=document.getElementById("navLinks");

menuToggle.addEventListener("click",()=>navLinks.classList.toggle("active"));

document.querySelectorAll(".nav-links a").forEach(link=>{
    link.addEventListener("click",()=>navLinks.classList.remove("active"));
});

const backToTop=document.getElementById("backToTop");
window.addEventListener("scroll",()=>{
    if(window.scrollY>400) backToTop.classList.add("show");
    else backToTop.classList.remove("show");
});

backToTop.addEventListener("click",()=>{
    window.scrollTo({top:0,behavior:"smooth"});
});

const sections=document.querySelectorAll("section");
const navItems=document.querySelectorAll(".nav-links a");

window.addEventListener("scroll",()=>{
    let current="";
    sections.forEach(section=>{
        if(window.scrollY>=section.offsetTop-120) current=section.id;
    });
    navItems.forEach(link=>{
        link.classList.toggle("active",link.getAttribute("href")==="#"+current);
    });
});

const revealElements=document.querySelectorAll(".skill-card,.project-card,.timeline-item,.about-container");
const observer=new IntersectionObserver(entries=>{
    entries.forEach(entry=>{
        if(entry.isIntersecting) entry.target.classList.add("visible");
    });
},{threshold:.15});
revealElements.forEach(element=>observer.observe(element));
